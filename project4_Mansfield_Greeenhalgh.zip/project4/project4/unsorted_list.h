/*
 The list implementation from the book.

 All function names copied exactly
*/
