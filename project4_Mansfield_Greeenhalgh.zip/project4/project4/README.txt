This is the project 4.
We shall simulate a processor.
HI! This is the read me!

This will not cause errors. HOORAY!!